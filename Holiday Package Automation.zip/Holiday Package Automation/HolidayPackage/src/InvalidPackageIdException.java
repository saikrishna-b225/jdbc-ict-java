public class InvalidPackageIdException extends Exception{
    //Creating public Constructor with parameters and calling constructor of super class
    public InvalidPackageIdException(String exception) {
		super(exception);
	}
}
	